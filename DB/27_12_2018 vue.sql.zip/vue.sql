-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 27, 2018 at 01:43 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vue`
--

-- --------------------------------------------------------

--
-- Table structure for table `upload_file`
--

DROP TABLE IF EXISTS `upload_file`;
CREATE TABLE `upload_file` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `filename` varchar(200) DEFAULT NULL,
  `mime` varchar(200) DEFAULT NULL,
  `path` varchar(200) DEFAULT NULL,
  `size` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `contact_no` varchar(15) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `image` varchar(200) DEFAULT NULL,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `contact_no`, `address`, `image`, `datetime`) VALUES
(1, 'Naim uddin', NULL, '01986873220', 'Dhaka, Bangladesh', NULL, '2018-12-27 08:27:53'),
(2, 'Md Foysal', NULL, '016888545566', 'Mirpur, Bangladesh', NULL, '2018-12-27 08:27:53'),
(3, 'Mahdi', NULL, '016554455', 'Uttara, Bangladesh', NULL, '2018-12-27 08:27:53'),
(4, 'Kamal', NULL, '01566455655', 'Khulna', NULL, '2018-12-27 08:27:53'),
(5, 'Hasan', NULL, '01776444', 'Rangpur', NULL, '2018-12-27 08:27:53'),
(6, 'test name', NULL, '0155545554855', 'Kalkini', NULL, '2018-12-27 08:27:53'),
(7, 'Md Mahin', NULL, '015664565', 'Park road, Dhaka', NULL, '2018-12-27 08:27:53'),
(10, 'Md Maruf', 'maruf@gmail.com', '0155545655', 'Madaripur', NULL, '2018-12-27 08:27:53'),
(11, 'Kamal Hossain', 'kamal@gmail.com', '0122554565', 'Kaligonj', NULL, '2018-12-27 08:27:53'),
(12, 'Marvin Gomez', 'marvin@beatnikbd.com', '01555554445', 'Dhaka', NULL, '2018-12-27 08:27:53'),
(13, 'Md Kamal uddin', 'kamal@gmail.com', '0155545554', 'Kaligonj Madaripur', NULL, '2018-12-27 08:27:53'),
(14, 'Mr Hasan', 'hasan@gmail.com', '34534534', 'Mogbazzar', NULL, '2018-12-27 08:27:53'),
(18, 'Hasib', 'hasib@gmail.com', '2342342342', 'Khulna', 'images/user/1545914476_5c24c86c32dd5.jpeg', '2018-12-27 08:27:53'),
(20, 'Md Foysal', 'foysal@gmail.com', '015555455', 'Dahka', 'images/user/1545914460_5c24c85c02390.jpeg', '2018-12-27 11:29:40'),
(21, 'Mahin', 'mahin@gmail.com', '01555', 'Dahka', 'images/user/1545914451_5c24c85379cdb.jpeg', '2018-12-27 11:31:06'),
(22, 'Mr', 'mr@gmail.com', '015545', 'abc', 'images/user/1545914413_5c24c82d72ded.jpeg', '2018-12-27 11:33:11'),
(23, 'adfad', 'adfa@gmail.com', '23423423', 'adfadf', 'images/user/1545913976_5c24c6789e014.jpeg', '2018-12-27 11:35:05'),
(24, 'adfad', 'adf@gmail.com', '345', 'adfad', 'images/user/1545913922_5c24c6423bed4.jpeg', '2018-12-27 11:57:22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `upload_file`
--
ALTER TABLE `upload_file`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `upload_file`
--
ALTER TABLE `upload_file`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
